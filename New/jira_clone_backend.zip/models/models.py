# Sample SQLAlchemy models
